# 🤖 Telegram Bot для Live Chat

## Налаштування

### 1. Створи Telegram бота
1. Відкрий [@BotFather](https://t.me/BotFather) в Telegram
2. Відправ `/newbot`
3. Введи назву бота (наприклад: `VORON TRADES Support`)
4. Введи username (наприклад: `vorontrades_support_bot`)
5. Збережи **токен** який видав BotFather

### 2. Отримай свій Chat ID
1. Відкрий [@userinfobot](https://t.me/userinfobot)
2. Відправ `/start`
3. Збережи свій **Chat ID**

### 3. Встанови залежності
```bash
cd bot
npm install
```

### 4. Налаштуй .env файл
Створи файл `.env` (скопіюй з `.env.example`):
```env
TELEGRAM_BOT_TOKEN=твій_токен_від_BotFather
ADMIN_CHAT_ID=твій_chat_id
PORT=3000
```

### 5. Запусти сервер
```bash
npm start
```

## Як це працює

### З боку сайту:
1. Користувач пише в чат
2. Повідомлення йде на `http://localhost:3000/api/chat-message`
3. Користувач отримує автовідповідь

### З боку менеджера:
1. Тобі в Telegram приходить повідомлення:
```
💬 Нове повідомлення з сайту

Session: abc123
Повідомлення: Скільки коштує підписка?

Відповідь: /reply_abc123 ваша_відповідь
```

2. Щоб відповісти, пишеш:
```
/reply_abc123 Підписка коштує $99/місяць. Перші 7 днів безкоштовно!
```

3. Користувач на сайті бачить твою відповідь в реальному часі!

## Деплой

### Heroku:
```bash
heroku create voron-trades-bot
heroku config:set TELEGRAM_BOT_TOKEN=твій_токен
heroku config:set ADMIN_CHAT_ID=твій_chat_id
git push heroku main
```

### Railway.app:
1. Зайди на railway.app
2. Підключи GitHub репозиторій
3. Додай змінні середовища
4. Деплой автоматичний

Після деплою замінь в `config.json`:
```json
{
  "leads_endpoint": "https://твій-домен.herokuapp.com/api/chat-message"
}
```
